(function($){	
$( document ).ready( function( )
{	
	$( ".entry-content").FancyIndex();
} );
})(jQuery);