(function($){	
$( document ).ready( function( )
{
	$( "body" ).FancyIndex(/* {
				hideWhenInactive: true,
				focusInitally: true,
				focusOnResize: true,
				focusOnScroll: true,
				focusOnHover: true,
				focusTimeout: 1000,
				firstOnly: false,
				forceLastActive: true,
				scrollToDuration: 1000,
				scrollOnClick: true,
				maxPrioritizedItems: 3
	}*/);
} );
})(jQuery);
